package com.innovationai.pigweight.net.netutils;

/**
 * @Author: Lucas.Cui
 * 时   间：2019/3/22
 * 简   述：<功能简述>
 */

public interface ProgressCancelListener {
    void onCancelProgress();
}
