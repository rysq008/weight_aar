package com.innovationai.piginsurance;

import android.app.Application;


/**
 * @Author: Lucas.Cui
 * 时   间：2019/5/23
 * 简   述：<功能简述>
 */
public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }
}
